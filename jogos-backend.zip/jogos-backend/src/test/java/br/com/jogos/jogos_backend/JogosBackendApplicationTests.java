package br.com.jogos.jogos_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JogosBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
