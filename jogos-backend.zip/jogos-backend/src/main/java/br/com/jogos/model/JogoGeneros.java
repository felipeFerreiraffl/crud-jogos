package br.com.jogos.model;

public enum JogoGeneros {
    ACAO, AVENTURA, TERROR, RPG, SIMULACAO, LUTA, CORRIDA, PLATAFORMA, MUSICA, ESTRATEGIA
}
